# Church Management System

This project is a simple church management system built in Python.

## Features
- Manage church members
- Track church events
- Record donations
- View a simple summary

## Run the app
From this folder, run:

```bash
python main.py
```

## Files
- `main.py` - the main application
- `church_data.json` - data file created automatically when the app runs
