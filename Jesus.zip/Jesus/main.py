import json
from pathlib import Path

DATA_FILE = Path(__file__).with_name("church_data.json")


class ChurchManagementSystem:
    def __init__(self):
        self.members = []
        self.events = []
        self.donations = []
        self.load_data()

    def load_data(self):
        if DATA_FILE.exists():
            with DATA_FILE.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
            self.members = data.get("members", [])
            self.events = data.get("events", [])
            self.donations = data.get("donations", [])
        else:
            self.members = [
                {"id": 1, "name": "Pastor Samuel", "phone": "0780000001", "email": "samuel@church.org", "role": "Pastor"},
                {"id": 2, "name": "Grace Mwangi", "phone": "0780000002", "email": "grace@church.org", "role": "Usher"},
            ]
            self.events = [
                {"id": 1, "title": "Sunday Worship", "date": "2026-06-28", "description": "Weekly service"},
            ]
            self.donations = [
                {"id": 1, "member": "Grace Mwangi", "amount": 5000.0, "note": "Offering"},
            ]
            self.save_data()

    def save_data(self):
        data = {
            "members": self.members,
            "events": self.events,
            "donations": self.donations,
        }
        with DATA_FILE.open("w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2)

    def add_member(self, name, phone, email, role):
        new_id = max([member["id"] for member in self.members], default=0) + 1
        self.members.append({
            "id": new_id,
            "name": name,
            "phone": phone,
            "email": email,
            "role": role,
        })
        self.save_data()

    def list_members(self):
        if not self.members:
            return "No members yet."
        lines = ["Members:"]
        for member in self.members:
            lines.append(f"- {member['id']}: {member['name']} ({member['role']})")
        return "\n".join(lines)

    def add_event(self, title, date, description):
        new_id = max([event["id"] for event in self.events], default=0) + 1
        self.events.append({
            "id": new_id,
            "title": title,
            "date": date,
            "description": description,
        })
        self.save_data()

    def list_events(self):
        if not self.events:
            return "No events yet."
        lines = ["Events:"]
        for event in self.events:
            lines.append(f"- {event['id']}: {event['title']} on {event['date']}")
        return "\n".join(lines)

    def record_donation(self, member, amount, note):
        new_id = max([donation["id"] for donation in self.donations], default=0) + 1
        self.donations.append({
            "id": new_id,
            "member": member,
            "amount": float(amount),
            "note": note,
        })
        self.save_data()

    def show_summary(self):
        total_donations = sum(donation["amount"] for donation in self.donations)
        return f"Total members: {len(self.members)}\nTotal events: {len(self.events)}\nTotal donations: {total_donations:.2f}"

    def show_menu(self):
        print("\nChurch Management System")
        print("1. View members")
        print("2. Add member")
        print("3. View events")
        print("4. Add event")
        print("5. Record donation")
        print("6. View summary")
        print("7. Quit")

    def run(self):
        while True:
            self.show_menu()
            choice = input("Choose an option: ").strip()
            if choice == "1":
                print(self.list_members())
            elif choice == "2":
                name = input("Member name: ")
                phone = input("Phone: ")
                email = input("Email: ")
                role = input("Role: ")
                self.add_member(name, phone, email, role)
                print("Member added successfully.")
            elif choice == "3":
                print(self.list_events())
            elif choice == "4":
                title = input("Event title: ")
                date = input("Event date (YYYY-MM-DD): ")
                description = input("Description: ")
                self.add_event(title, date, description)
                print("Event added successfully.")
            elif choice == "5":
                member = input("Member name: ")
                amount = input("Amount: ")
                note = input("Note: ")
                self.record_donation(member, amount, note)
                print("Donation recorded successfully.")
            elif choice == "6":
                print(self.show_summary())
            elif choice == "7":
                print("Goodbye!")
                break
            else:
                print("Invalid option. Try again.")


if __name__ == "__main__":
    ChurchManagementSystem().run()
